import{u as r}from"./5587f402.B-8BFOZr.js";import{P as o}from"./164ad2e3.DrLvtOSs.js";function s(){return r(o)}export{s as u};
